package com.eventbooking.order_service.service;

import com.eventbooking.order_service.kafka.OrderProducer;
import com.eventbooking.order_service.model.Order;
import com.eventbooking.order_service.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderProducer orderProducer;

    public Order createOrder(Order order) {
        order.setCreatedAt(LocalDateTime.now());
        Order saved = orderRepository.save(order);

        // Gửi message đơn giản sang Kafka
        String message = String.format("OrderID: %d, EventID: %s, Quantity: %d",
                saved.getId(), saved.getEventId(), saved.getQuantity());

        orderProducer.sendOrderEvent(message);

        return saved;
    }
    @KafkaListener(topics = "order-events", groupId = "log-group")
    public void listen(String message) {
        System.out.println("🛎️ Received from Kafka: " + message);
    }
}